const API_BASE = window.localStorage.getItem("apiBase") || "http://localhost:8000";
const REFRESH_MS = 4000;

const statusPill = document.getElementById("status-pill");
const lastUpdated = document.getElementById("last-updated");
const eventsBody = document.getElementById("events-body");
const funnelBars = document.getElementById("funnel-bars");

function setStatus(ok, message) {
  statusPill.textContent = message;
  statusPill.classList.remove("ok", "error");
  statusPill.classList.add(ok ? "ok" : "error");
}

function setText(id, value) {
  const node = document.getElementById(id);
  if (node) {
    node.textContent = value;
  }
}

function renderFunnel(stages) {
  funnelBars.innerHTML = "";
  if (!stages || stages.length === 0) {
    return;
  }

  const max = Math.max(...stages.map((s) => s.count || 0), 1);
  for (const stage of stages) {
    const row = document.createElement("div");
    row.className = "bar-row";

    const name = document.createElement("span");
    name.textContent = stage.stage;

    const barWrap = document.createElement("div");
    const bar = document.createElement("div");
    bar.className = "bar";
    bar.style.width = `${Math.max(2, Math.round(((stage.count || 0) / max) * 100))}%`;
    barWrap.appendChild(bar);

    const count = document.createElement("strong");
    count.textContent = stage.count;

    row.appendChild(name);
    row.appendChild(barWrap);
    row.appendChild(count);
    funnelBars.appendChild(row);
  }
}

function renderEvents(events) {
  eventsBody.innerHTML = "";
  for (const ev of events) {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${ev.event_time || "--"}</td>
      <td>${ev.event_type || "--"}</td>
      <td>${ev.camera_id || "--"}</td>
      <td>${ev.session_id || "--"}</td>
      <td>${typeof ev.confidence === "number" ? ev.confidence.toFixed(2) : "--"}</td>
    `;
    eventsBody.appendChild(tr);
  }
}

async function refreshDashboard() {
  try {
    const [metricsRes, funnelRes, eventsRes] = await Promise.all([
      fetch(`${API_BASE}/metrics`),
      fetch(`${API_BASE}/funnel`),
      fetch(`${API_BASE}/events/sample?limit=12`),
    ]);

    if (!metricsRes.ok || !funnelRes.ok || !eventsRes.ok) {
      throw new Error("API responded with non-200 status");
    }

    const metrics = await metricsRes.json();
    const funnel = await funnelRes.json();
    const eventsPayload = await eventsRes.json();

    setText("entries", metrics.entries);
    setText("purchasers", metrics.purchasers);
    setText("conversion-rate", metrics.conversion_rate);
    setText("transactions", metrics.transactions);
    setText("vision-mode", metrics.vision_processing_mode);
    setText("cameras-processed", metrics.cameras_processed);
    setText("vision-entries", metrics.vision_entry_events);
    setText("vision-exits", metrics.vision_exit_events);

    renderFunnel(funnel.stages || []);
    renderEvents(eventsPayload.events || []);

    const now = new Date().toLocaleTimeString();
    lastUpdated.textContent = `Last updated: ${now}`;
    setStatus(true, "Live");
  } catch (error) {
    setStatus(false, "Disconnected");
    lastUpdated.textContent = `Last updated: error`;
  }
}

setStatus(false, "Connecting...");
refreshDashboard();
setInterval(refreshDashboard, REFRESH_MS);
